import xbmc
import time

xbmc.executebuiltin('RunScript(plugin.video.themoviedb.helper,library_autoupdate,busy_dialog,force)')
