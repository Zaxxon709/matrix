import xbmc

xbmc.executebuiltin('RunPlugin(plugin://plugin.program.autowidget/?mode=force)')
xbmc.executebuiltin('PlayMedia(&quot;plugin://plugin.program.709wizard/?mode=savetrakt&amp;name=all&quot;)')
xbmc.executebuiltin('PlayMedia(&quot;plugin://plugin.program.709wizard/?mode=savedebrid&amp;name=all&quot;)')
