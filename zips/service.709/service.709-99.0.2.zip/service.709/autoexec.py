import xbmc
import time

xbmc.executebuiltin('RunPlugin(plugin://plugin.program.autowidget/?mode=force)')
time.sleep(5)
xbmc.executebuiltin('PlayMedia(plugin://plugin.program.709wizard/?mode=savetrakt&name=all)')
time.sleep(3)
xbmc.executebuiltin('PlayMedia(plugin://plugin.program.709wizard/?mode=savedebrid&name=all)')
