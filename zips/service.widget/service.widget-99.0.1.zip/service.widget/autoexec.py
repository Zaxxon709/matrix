import xbmc

xbmc.executebuiltin('RunPlugin(plugin://plugin.program.autowidget/?mode=force)')
